public class Example15_16 {
   public static void main(String args[]) {
      WindowEnter win=new WindowEnter();
      win.setTitle("带确认对话框的窗口"); 
      win.setBounds(80,90,200,300);
   }
}
