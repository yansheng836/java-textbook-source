public class Example15_7 {
   public static void main(String args[]) {
      WindowItemEvent win=new WindowItemEvent();
      win.setBounds(100,100,460,360);
      win.setTitle("处理ItemEvent事件");
   }
}
