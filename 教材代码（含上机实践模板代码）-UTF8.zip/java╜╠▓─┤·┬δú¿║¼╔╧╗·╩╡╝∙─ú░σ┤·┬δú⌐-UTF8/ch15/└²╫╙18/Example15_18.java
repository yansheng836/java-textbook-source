public class Example15_18 {
   public static void main(String args[]) {
      WindowReader win=new WindowReader();
      win.setTitle("使用文件对话框读写文件");
      win.setBounds(80,90,200,300);
   }
}
