public class Example15_8 {
   public static void main(String args[]) {
      WindowDocument win=new WindowDocument();
      win.setBounds(10,10,460,360);
      win.setTitle("处理DocumentEvent事件");
   }
}
