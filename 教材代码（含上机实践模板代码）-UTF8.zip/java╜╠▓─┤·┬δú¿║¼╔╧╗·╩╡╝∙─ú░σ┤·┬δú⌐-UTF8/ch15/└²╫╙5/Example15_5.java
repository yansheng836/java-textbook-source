public class Example15_5 {
   public static void main(String args[]) {
      WindowActionEvent win=new WindowActionEvent();
      win.setBounds(100,100,310,260);
      win.setTitle("处理ActionEvent事件");
   }
}
