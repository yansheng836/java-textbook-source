public class Example15_17 {
   public static void main(String args[]) {
      WindowColor win=new WindowColor();
      win.setTitle("带颜色对话框的窗口"); 
      win.setBounds(80,90,200,300);
   }
}
