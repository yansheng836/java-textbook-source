public class Example15_11 {
   public static void main(String args[]) {
      Win win=new Win();
      win.setTitle("输入序列号");
      win.setBounds(10,10,460,360);
   }
}
