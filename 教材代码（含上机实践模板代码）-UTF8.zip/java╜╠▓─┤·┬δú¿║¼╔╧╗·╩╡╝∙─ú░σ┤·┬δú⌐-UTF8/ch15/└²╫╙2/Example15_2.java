public class Example15_2 {
   public static void main(String args[]) {
      WindowMenu win=new WindowMenu("带菜单的窗口",20,30,200,190);
   }
}
