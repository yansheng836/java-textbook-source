public class Example15_10 {
   public static void main(String args[]) {
      WindowMove win=new WindowMove();
      win.setTitle("处理鼠标拖动事件"); 
      win.setBounds(10,10,460,360);
   }
}
