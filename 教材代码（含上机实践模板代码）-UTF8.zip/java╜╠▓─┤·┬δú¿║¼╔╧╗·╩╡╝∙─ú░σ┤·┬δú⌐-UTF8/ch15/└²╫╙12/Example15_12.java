public class Example15_12 {
   public static void main(String args[]) {
      WindowPolice win = new WindowPolice();
   }
}

