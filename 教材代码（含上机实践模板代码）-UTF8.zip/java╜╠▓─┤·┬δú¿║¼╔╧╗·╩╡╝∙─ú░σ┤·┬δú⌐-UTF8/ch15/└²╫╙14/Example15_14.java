public class Example15_14 {
   public static void main(String args[]) {
      WindowMess win=new WindowMess();
      win.setTitle("带消息对话框的窗口"); 
      win.setBounds(80,90,200,300);
   }
}
