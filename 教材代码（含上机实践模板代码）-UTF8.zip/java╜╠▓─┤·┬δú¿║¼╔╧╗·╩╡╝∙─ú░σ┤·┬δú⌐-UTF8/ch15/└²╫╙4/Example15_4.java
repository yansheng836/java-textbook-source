public class Example15_4 {
   public static void main(String args[]) {
      WindowBoxLayout win=new WindowBoxLayout();
      win.setBounds(100,100,310,260);
      win.setTitle("嵌套盒式布局容器");
   }
}
