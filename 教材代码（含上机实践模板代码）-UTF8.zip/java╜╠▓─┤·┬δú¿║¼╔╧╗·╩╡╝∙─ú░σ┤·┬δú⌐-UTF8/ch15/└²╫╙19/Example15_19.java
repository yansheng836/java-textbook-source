public class Example15_19 {
   public static void main(String args[]) {
      MyWindow win=new MyWindow();
      win.setTitle("带自定义对话框的窗口"); 
      win.setSize(200,300);
   }
}
