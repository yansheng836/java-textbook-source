public class Example15_13 {
   public static void main(String args[]){
      WindowTriangle win=new WindowTriangle();
      win.setTitle("使用MVC结构"); 
      win.setBounds(100,100,420,260);
   }
}


