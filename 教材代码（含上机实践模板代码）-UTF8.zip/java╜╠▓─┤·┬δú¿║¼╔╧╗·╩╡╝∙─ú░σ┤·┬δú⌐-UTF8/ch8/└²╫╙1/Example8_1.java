public class Example8_1 {
   public static void main(String args[]) {
      RedCowForm form = new RedCowForm("红牛农场");
      form.showCowMess();
   }   
}

