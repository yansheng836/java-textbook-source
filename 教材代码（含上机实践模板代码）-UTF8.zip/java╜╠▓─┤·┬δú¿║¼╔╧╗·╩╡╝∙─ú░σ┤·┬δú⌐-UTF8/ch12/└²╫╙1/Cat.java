public class Cat {
   public String toString() {
      return "一只小花猫";
   }
}
