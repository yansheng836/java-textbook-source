public class Dog {
   public String toString() {
      return "一条小狗";
   }
}
