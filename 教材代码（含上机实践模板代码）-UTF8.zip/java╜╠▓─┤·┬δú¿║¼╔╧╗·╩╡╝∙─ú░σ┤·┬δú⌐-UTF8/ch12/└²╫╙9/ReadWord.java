import java.util.*;
import java.io.*;
public class ReadWord {
   public void putWordToHashMap(HashMap<String,String> hashtable,File file) {
       try{ Scanner sc = new Scanner(file); 
            while(sc.hasNext()){
               String englishWord=sc.next();
               String chineseWord=sc.next(); 
               hashtable.put(englishWord,chineseWord); 
             }
       }
       catch(Exception e){}  
   } 
}
