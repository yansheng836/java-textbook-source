public class Hello {
   public static void main (String args[]) {
      System.out.println("这是一个简单的Java应用程序");
   }
}
