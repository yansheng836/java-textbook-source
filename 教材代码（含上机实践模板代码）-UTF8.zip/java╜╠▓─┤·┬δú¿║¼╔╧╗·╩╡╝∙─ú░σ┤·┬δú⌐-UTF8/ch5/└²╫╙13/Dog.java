public class Dog extends Animal {
   public void cry() {
      System.out.println("汪汪...汪汪"); 
   }  
   public String getAnimalName() {
      return "狗";
   }
}
