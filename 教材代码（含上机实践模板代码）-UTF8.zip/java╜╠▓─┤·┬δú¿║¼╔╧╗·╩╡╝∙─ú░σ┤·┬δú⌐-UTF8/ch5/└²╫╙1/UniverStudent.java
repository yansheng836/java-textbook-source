public class UniverStudent extends Student {
   int multi(int x,int y) {
      return x*y;
   }  
   double div(double x,double y) {
      return x/y;
   }   
}
