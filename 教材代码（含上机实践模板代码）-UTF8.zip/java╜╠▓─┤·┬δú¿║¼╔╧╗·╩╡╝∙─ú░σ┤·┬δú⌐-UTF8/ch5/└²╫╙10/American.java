public class American extends People {
   void showBodyMess() {
      System.out.println("bodyHeight:"+height+"cm"+" bodyWeight:"+weight+"kg"); 
   }  
   void speakEnglish() {
      System.out.println("I am Amerian");
   }
}

