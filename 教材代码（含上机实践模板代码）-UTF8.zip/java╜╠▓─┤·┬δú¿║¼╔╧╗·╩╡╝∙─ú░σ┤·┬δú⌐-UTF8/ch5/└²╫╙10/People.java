public class People {
   int height;
   double weight;
   void showBodyMess() {
      System.out.printf("*********\n"); 
   } 
   void mustDoingThing() {
      System.out.println("吃饭、睡觉... ...饮水");
   } 
}

