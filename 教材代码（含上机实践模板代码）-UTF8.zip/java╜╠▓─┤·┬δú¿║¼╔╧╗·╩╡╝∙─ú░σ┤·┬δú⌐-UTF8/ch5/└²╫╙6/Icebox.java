public class Icebox extends HomeEletricity {
    public void showMess(){
       System.out.println("我是冰箱,重量是"+weight+"kg");
    }
}

