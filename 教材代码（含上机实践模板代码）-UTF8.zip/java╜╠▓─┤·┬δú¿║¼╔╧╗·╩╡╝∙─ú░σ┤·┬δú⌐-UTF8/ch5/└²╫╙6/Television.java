public class Television extends HomeEletricity {
    public void showMess(){
       System.out.println("我是电视机,重量是"+weight+"kg");
    }
}

