public class HomeEletricity {
    int weight;
    public void setWeight(int w) {
        weight=w;
    } 
    public void showMess(){
       System.out.println("我是家用电器");
    }
}
