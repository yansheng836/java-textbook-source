public class Japan implements Computable { ////Japan类实现Computable接口
   int number;
   public int f(int x) {
      return 46+x; 
   }
}
