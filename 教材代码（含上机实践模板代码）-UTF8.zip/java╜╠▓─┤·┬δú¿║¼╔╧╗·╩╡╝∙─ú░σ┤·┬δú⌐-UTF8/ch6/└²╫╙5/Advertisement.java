public interface Advertisement { //接口
      public void showAdvertisement();
      public String getCorpName();
}
