public class Circle 
{
   double radius;
   double getArea() 
   {  
      return 3.1415926*radius;
   }
}
