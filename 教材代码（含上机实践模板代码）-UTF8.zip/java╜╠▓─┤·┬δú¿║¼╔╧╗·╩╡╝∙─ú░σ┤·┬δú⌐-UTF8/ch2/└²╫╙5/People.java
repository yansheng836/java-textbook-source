public class People 
{
   float weight;
   int height;
   void speak() 
   {  
      System.out.println("我的身高是:"+height+"cm");
      System.out.println("我的体重是:"+weight+"kg");
   }
}
