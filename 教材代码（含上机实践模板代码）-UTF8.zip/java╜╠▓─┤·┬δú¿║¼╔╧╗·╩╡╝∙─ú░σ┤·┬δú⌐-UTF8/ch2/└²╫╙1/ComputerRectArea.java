public class ComputerRectArea  {
    public static void main(String args[]) {
       double length; //长
       double width;  //宽
       double area;   //面积
       length=23.89;
       width=108.87;
       area=length*width; //计算面积
       System.out.println(area);
    }
} 
