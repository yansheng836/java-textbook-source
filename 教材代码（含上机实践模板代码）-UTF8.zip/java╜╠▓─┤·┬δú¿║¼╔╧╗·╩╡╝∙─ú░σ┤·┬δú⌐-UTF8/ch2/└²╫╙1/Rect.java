public class Rect 
{
   double width;  //矩形的宽 
   double height; //矩形的高
   double getArea() 
   {
      double area=width*height;
      return area;
   }
}
