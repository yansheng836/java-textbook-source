public class Example7_6{
   public static void main(String args[]){
        Weekday x=Weekday.星期日;
        if(x==Weekday.星期日) {
          System.out.println(x);
          System.out.println("今天我休息");
        }
   }
}

