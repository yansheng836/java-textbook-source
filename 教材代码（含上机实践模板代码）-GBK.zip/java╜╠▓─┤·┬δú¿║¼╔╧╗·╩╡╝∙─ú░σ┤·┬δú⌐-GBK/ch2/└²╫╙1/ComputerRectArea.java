public class ComputerRectArea  {
    public static void main(String args[]) {
       double length; //��
       double width;  //��
       double area;   //���
       length=23.89;
       width=108.87;
       area=length*width; //�������
       System.out.println(area);
    }
} 
