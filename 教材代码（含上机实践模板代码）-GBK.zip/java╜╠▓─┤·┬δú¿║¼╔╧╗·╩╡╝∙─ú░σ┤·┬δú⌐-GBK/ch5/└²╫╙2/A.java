public class A {
    private int x;
    public void setX(int x) {
       this.x=x;
    } 
    public int getX() {
       return x;
    }
}
