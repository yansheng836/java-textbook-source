public class Dog {
   public String toString() {
      return "һ��С��";
   }
}
