public class ShowObject<E> { 
    public void showMess (E b) {
       String mess = b.toString(); 
       System.out.println(mess);   
    }
}
