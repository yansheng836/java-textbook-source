public class Cat {
   public String toString() {
      return "һֻС��è";
   }
}