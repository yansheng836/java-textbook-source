abstract class InputAlphabet {
   public abstract void input();
}


