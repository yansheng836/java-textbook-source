public class ShowBoard {
   void showMess(InputAlphabet show) {
     show.input();   
   } 
}


