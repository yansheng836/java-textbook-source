public class Example8_1 {
   public static void main(String args[]) {
      RedCowForm form = new RedCowForm("��ţũ��");
      form.showCowMess();
   }   
}

