public interface Computable {
   int MAX=100;
   int f(int x);
}

