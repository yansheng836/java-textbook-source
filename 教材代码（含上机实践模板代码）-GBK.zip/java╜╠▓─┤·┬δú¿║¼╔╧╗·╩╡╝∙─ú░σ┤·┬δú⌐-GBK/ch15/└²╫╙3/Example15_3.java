public class Example15_3 {
   public static void main(String args[]) {
      ComponentInWindow win=new ComponentInWindow();
      win.setBounds(100,100,310,260);
      win.setTitle("�������");
   }
}
