public class Example15_6 {
   public static void main(String args[]) {
      WindowActionEvent win=new WindowActionEvent();
      win.setBounds(100,100,460,360);
      win.setTitle("����ActionEvent�¼�");
   }
}
