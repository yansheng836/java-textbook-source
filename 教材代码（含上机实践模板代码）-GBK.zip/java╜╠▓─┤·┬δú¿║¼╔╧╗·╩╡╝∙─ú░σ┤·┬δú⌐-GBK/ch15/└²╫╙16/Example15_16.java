public class Example15_16 {
   public static void main(String args[]) {
      WindowEnter win=new WindowEnter();
      win.setTitle("��ȷ�϶Ի���Ĵ���"); 
      win.setBounds(80,90,200,300);
   }
}
