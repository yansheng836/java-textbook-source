package tom.jiafei;
public class Example4_12 {
   public static void main(String args[]){
      Student stu=new Student(10201);
      stu.speak();
      System.out.println("����İ���Ҳ��tom.jiafei");
   }
}
