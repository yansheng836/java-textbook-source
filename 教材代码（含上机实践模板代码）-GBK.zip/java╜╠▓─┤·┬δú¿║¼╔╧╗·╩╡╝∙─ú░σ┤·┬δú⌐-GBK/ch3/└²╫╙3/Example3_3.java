public class Example3_3 {
   public static void main(String args[]) {
       ComputerSum computer = new ComputerSum();
       computer.giveSum(8,10);
   }
}