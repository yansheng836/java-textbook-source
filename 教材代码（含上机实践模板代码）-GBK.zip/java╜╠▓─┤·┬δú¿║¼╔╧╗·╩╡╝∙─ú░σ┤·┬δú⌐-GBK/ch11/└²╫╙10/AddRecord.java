import java.sql.*;
public class AddRecord {
   String databaseName="";       	//���ݿ���
   String tableName="";             	//����
   String number="",        		//��Ʒ�� 
          name="",        			//����
          madeTime;       			//��������
   double price;            			//�۸�
   public AddRecord() {
      try{ Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      }
      catch(ClassNotFoundException e) {
         System.out.print(e);
      } 
    }
   public void setDatabaseName(String s) {
      databaseName=s.trim();
   }
   public void setTableName(String s) {
      tableName=s.trim();
   }
    public void setNumber(String s) {
       number=s.trim();
    }
    public void setName(String s) {
       name=s.trim();
    }
    public void setPrice(double n) {
       price=n;
    }
    public void setMadeTime(String b) {
        madeTime=b;
    }
    public String addRecord() {
       String str="";
       Connection con;
       PreparedStatement sql;   //Ԥ�������
       try { String uri="jdbc:derby:"+databaseName+";create=true"; 
             con=DriverManager.getConnection(uri);
             String insertCondition="INSERT INTO "+tableName+" VALUES (?,?,?,?)";
             sql=con.prepareStatement(insertCondition);
             if(number.length()>0) {
               sql.setString(1,number);
               sql.setString(2,name);
               sql.setString(3,madeTime);
               sql.setDouble(4,price);
               int m=sql.executeUpdate();
               if(m!=0) 
                   str="�Ա�������"+m+"����¼�ɹ�";
               else 
                  str="���Ӽ�¼ʧ��";
            }
            else {
               str="����Ҫ�й�Ա��";
            }
            con.close();
       }
       catch(SQLException e) { 
            str="û���ṩ���ӵ����ݻ�"+e;
       }
       return str;
    }
}  
